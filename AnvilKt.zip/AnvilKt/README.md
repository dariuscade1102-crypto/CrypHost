# AnvilKt — local Minecraft server host, in Kotlin

A scaffold for an Anvil-MC/ARM-MC-style Android app: runs a real Paper/Fabric
server jar on-device, tunnels it to the internet with zero port forwarding,
auto-installs Geyser/Floodgate for Bedrock crossplay, and gives you a live
console + mod installer, all from a foreground service that survives
backgrounding.

## What's implemented here

| Requirement | File(s) |
|---|---|
| 1. Local self-hosting engine | `server/ServerProcessManager.kt`, `server/JreProvisioner.kt` |
| 2. Zero-port-forward tunnel | `tunnel/TunnelManager.kt` |
| 3. Java/Bedrock crossplay | `network/ModrinthRepository.kt` (`installBedrockCrossplay`) |
| 4. Management dashboard | `ui/DashboardScreen.kt`, `ui/DashboardViewModel.kt` |
| 5. Mod/plugin installer | `network/ModrinthApi.kt`, `network/ModrinthRepository.kt` |
| 6. Background execution | `service/ServerForegroundService.kt` |

This is a working architecture and compiles conceptually against the listed
Gradle dependencies, but it is **not a drop-in-and-ship APK** — three pieces
are binaries/assets too large and licensing-specific to generate here.

## Three things you must supply yourself

### 1. An embedded ARM JRE (required — nothing runs without this)
Android has no `java` binary. Server jars need a real JVM. Options, easiest
first:
- **Termux's `openjdk-17` package** — extract the `.deb` from
  `https://packages.termux.dev`, pull out `data/data/com.termux/files/usr`,
  zip it as `jre-arm64.zip`, drop into `app/src/main/assets/`.
- **Azul Zulu / BellSoft Liberica ARM builds** — both publish tar.gz JDKs for
  `linux-aarch64` that run fine under Android's Linux kernel via `exec()`,
  though you may need to patch a few `/proc` reads some JVMs do at startup
  (this varies by vendor/version — test on-device before shipping).

Either way: `JreProvisioner` expects `assets/jre-arm64.zip` (and optionally
`jre-armv7.zip`) containing a `bin/java` at its root.

### 2. The playit.gg agent binary (required for requirement #2)
Download the ARM64 build from `https://github.com/playit-cloud/playit-agent`
releases, rename it `libplayit_agent.so`, place under
`app/src/main/jniLibs/arm64-v8a/`. The `.so` extension and `jniLibs` location
are required by Android's APK packaging even though it's an ordinary
executable, not a shared library — this is the standard trick self-hosting
apps use to ship arbitrary ELF binaries.

Verify `TunnelManager`'s log-parsing regexes against whatever agent version
you actually bundle — the exact stdout wording isn't a stable API.

### 3. Server jars / Bedrock binary
PaperMC jars are fetched from `https://api.papermc.io` per version+build; add
a small `PaperDownloader` (same Retrofit + OkHttp pattern as
`ModrinthRepository`) if you want in-app "pick a version, download it" rather
than the user sideloading a jar manually. Bedrock Dedicated Server has no
public download API — Mojang requires clicking through their site — so that
path realistically needs the user to download it once and pick the file via
Storage Access Framework.

## Full app surface (this update)

The scaffold now mirrors the reference app's full navigation, not just a
single server's dashboard:

| Screen | File |
|---|---|
| Home (server list, tunnel selector) | `ui/home/HomeScreen.kt` |
| Guided Setup wizard (6 steps) | `ui/setup/GuidedSetupScreen.kt` |
| Server settings — General/Software/World/Mods & Plugins/Performance/Network | `ui/server/*.kt` |
| Console (live output, quick commands, player rail) | `ui/console/ConsoleScreen.kt` |
| Files | `ui/files/FilesScreen.kt` |
| Profile (Google Sign-In, plan tier) | `ui/profile/ProfileScreen.kt` |
| Navigation graph + bottom bar | `ui/nav/AppRoot.kt`, `ui/nav/Destinations.kt` |
| Shared server list/state | `data/ServerRepository.kt` |

`ServerRepository` is an in-memory singleton — every screen reads and
writes through it, which is why editing RAM in the Performance tab and
seeing it reflected on the Home card works without any manual wiring. Swap
its backing `MutableStateFlow<List<ServerConfig>>` for a Room DAO when you
need configs to survive a process death; nothing above it needs to change.

### Player management rail (Console screen)

Vanilla/Paper expose no structured player-roster API — the only way to know
who's online is parsing the `/list` command's own text response ("There are
2 of a max of 10 players online: Notch, Steve"). `ConsoleScreen.kt` does
exactly that (`parsePlayerList`) and surfaces the result as a rail with
kick/ban/whitelist per player: side-by-side with the console on wide
layouts (tablets, landscape), collapsed below it on phones. Re-issue `/list`
on an interval once this is wired to the real process (see the
`LaunchedEffect` comment in that file) so the roster doesn't go stale
between joins/leaves.

## Admin dashboard

Reached via the shield icon in Home's top bar (`ui/admin/AdminDashboardScreen.kt`).
Rolls up every server's live status (online/offline, player count) plus a
per-server collaborator list with three roles:

- **Owner** — implicit for whoever created the server; the only role that
  can remove other collaborators.
- **Admin** — full console + settings access, cannot remove the Owner.
- **Viewer** — read-only console, no settings access. (Enforcing the
  read-only part is a small gate to add in `ConsoleScreen.kt` — check the
  current user's role from `AdminRepository.collaboratorsFor(serverId)`
  before rendering the command input field/quick-command chips.)

Backed by `data/Collaborator.kt` + `data/AdminRepository.kt`, in-memory like
`ServerRepository`. One real limitation worth flagging: **"Invite by email"
currently only grants access in this device's local state.** For an invited
collaborator to actually see the server on *their* device, you need the
backend session layer mentioned in `GoogleAuthManager`'s class doc — some
server-side source of truth that maps "this Google-verified email" to
"these server IDs," which this device's local `AdminRepository` map can't
provide on its own. Local-only is fine for a single household sharing one
phone's app install; cross-device sharing needs that backend piece.

## Google Sign-In + password storage

- **`auth/GoogleAuthManager.kt`** — Sign in with Google via Credential
  Manager (the current, non-deprecated API; the old
  `GoogleSignInClient`/One Tap APIs are on their way out). You must:
  1. Create an OAuth 2.0 **Web application** client ID in Google Cloud
     Console (APIs & Services → Credentials) — yes, Web, not Android, even
     though this is an Android app; that's how the ID-token flow is
     designed.
  2. Also register an **Android** OAuth client in the same project, tied to
     this app's package name (`com.anvilkt.app`) and your signing
     certificate's SHA-1 fingerprint (`./gradlew signingReport` to get it).
  3. Replace `GOOGLE_WEB_CLIENT_ID` in `ProfileScreen.kt` with the Web
     client ID from step 1.
  - What you get back is an identity (email + a verifiable ID token), not
    an account system by itself. If servers/configs should sync across
    devices, that needs a backend that verifies the ID token server-side
    and issues its own session — this scaffold stops at "confirm who signed
    in," deliberately, since a backend is a separate piece of
    infrastructure this repo doesn't include.

- **`auth/SecureCredentialStore.kt`** — wraps `EncryptedSharedPreferences`
  (Android Keystore-backed AES-256) for any password this app stores
  locally. Currently used for the Network tab's RCON password field
  (`ui/server/NetworkTab.kt`) — deliberately kept **out** of `ServerConfig`,
  since that model isn't encrypted at rest. If you add more local secrets
  (an admin-panel password, a Discord bot webhook token), route them
  through this same store rather than adding fields to `ServerConfig`.

## Tablet / larger-screen support

- **ABIs**: `arm64-v8a` and `armeabi-v7a` cover phones and nearly all Android
  tablets. `x86_64` is now also built, for x86 tablets and Chromebooks in
  tablet mode — but remember each ABI needs its *own* embedded JRE zip and
  playit-agent binary (see the assets section above); adding the ABI to
  `build.gradle.kts` alone doesn't get you a working binary for it.
- **Layout**: `DashboardScreen` now branches on `WindowWidthSizeClass`
  (Compact vs Medium/Expanded) rather than checking device type — this is
  the correct Android-recommended signal, since a split-screened tablet or a
  phone in landscape can report a different class than the raw screen size
  would suggest. Wide layouts show the console and a player-management rail
  side-by-side; the rail is currently an empty slot (see the TODO comment in
  `DashboardScreen.kt`) since populating it needs a player-list data source
  (parsing `/list` output, or a small Paper plugin exposing an HTTP/RCON
  bridge) that isn't built yet.
- The manifest declares `configChanges` for orientation/screen size so
  rotating a device or unfolding a foldable mid-session re-triggers the
  layout switch live, instead of restarting the Activity (which would be
  jarring given the running server/console state this screen holds).

## Design notes worth knowing before you extend this

- **Battery-optimization exemption.** The foreground service alone is not
  enough on MIUI/One UI/ColorOS-style OEM skins; you need a one-time runtime
  prompt (`Intent.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`) or the OS
  will still kill the process under memory pressure. Not included in this
  scaffold — add a `BatteryOptimizationHelper` and call it from
  `MainActivity.onCreate`.
- **Storage permissions.** `MANAGE_EXTERNAL_STORAGE` in the manifest is a
  restricted permission on Play Store review; if you plan to publish (rather
  than sideload), keep everything in app-scoped storage (`filesDir`,
  `getExternalFilesDir`) instead and drop that permission entirely.
- **EULA.** `ServerProcessManager.ensureEula` only ever writes `eula=true` if
  your UI captured explicit consent — don't wire a "just make it work"
  shortcut that silently agrees to Mojang's EULA on the user's behalf.
- **iOS is not covered.** Apple's App Store sandboxing model prohibits
  running arbitrary downloaded/JIT-compiled binaries in a foreground app,
  which is exactly what this whole architecture depends on. A true iOS port
  isn't a porting exercise — it's not possible within App Store policy.
  Desktop (a Compose Multiplatform or Electron build) is the realistic
  cross-platform path if you want this off Android too.
