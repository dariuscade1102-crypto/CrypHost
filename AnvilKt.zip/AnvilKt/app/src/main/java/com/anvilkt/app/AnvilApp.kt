package com.anvilkt.app

import android.app.Application

class AnvilApp : Application()
