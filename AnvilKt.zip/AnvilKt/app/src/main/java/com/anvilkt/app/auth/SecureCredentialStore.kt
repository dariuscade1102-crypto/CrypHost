package com.anvilkt.app.auth

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Backs every password this app stores locally — RCON passwords, any future
 * admin-panel credentials — with a key in the Android Keystore (hardware-
 * backed on most devices), never plaintext SharedPreferences or a plain
 * file. Values are encrypted at rest and only decryptable by this app on
 * this device; there's no cloud sync of these, by design — a server's RCON
 * password only ever needs to exist where the server itself runs.
 */
class SecureCredentialStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "anvilkt_secure_credentials",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun setRconPassword(serverId: String, password: String) {
        prefs.edit().putString(rconKey(serverId), password).apply()
    }

    fun getRconPassword(serverId: String): String? = prefs.getString(rconKey(serverId), null)

    fun clearRconPassword(serverId: String) {
        prefs.edit().remove(rconKey(serverId)).apply()
    }

    /** Generic slot for anything else that shouldn't touch ServerConfig
     *  (which, unlike this store, isn't encrypted — see README note). */
    fun setSecret(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun getSecret(key: String): String? = prefs.getString(key, null)
    fun clearSecret(key: String) = prefs.edit().remove(key).apply()

    private fun rconKey(serverId: String) = "rcon_password:$serverId"
}
