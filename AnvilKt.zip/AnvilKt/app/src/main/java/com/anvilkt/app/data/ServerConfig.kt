package com.anvilkt.app.data

enum class ServerLoader(val displayName: String, val badge: String) {
    PAPER("Paper", "Recommended"),
    VANILLA("Vanilla", "Official"),
    FABRIC("Fabric", "Mods"),
    NEOFORGE("NeoForge", "Modded"),
    PURPUR("Purpur", "Plugins"),
    POWERNUKKITX("PowerNukkitX", "Experimental") // Bedrock-only
}

enum class Gamemode { SURVIVAL, CREATIVE, ADVENTURE, SPECTATOR }
enum class Difficulty { PEACEFUL, EASY, NORMAL, HARD }
enum class WorldType { NORMAL, FLAT, LARGE_BIOMES, AMPLIFIED }
enum class TunnelMode { LOCAL_ONLY, PLAYIT_GG, CLOUDFLARE }

/**
 * Everything a server's settings tabs can edit. Mirrors the six-tab layout
 * of the reference app (General / Software / World / Mods & Plugins /
 * Performance / Network) so each tab is just a view over one slice of this.
 */
data class ServerConfig(
    val id: String,
    val name: String,                       // folder name / display name
    val motd: String = "A Minecraft Server",
    val iconPath: String? = null,            // custom server icon, user-picked

    // General tab
    val gamemode: Gamemode = Gamemode.SURVIVAL,
    val difficulty: Difficulty = Difficulty.EASY,
    val hardcore: Boolean = false,

    // Software tab
    val loader: ServerLoader = ServerLoader.PAPER,
    val minecraftVersion: String = "1.21.1",
    val jarFileName: String? = null,         // e.g. "paper-26.2-123.jar"
    val jarPath: String? = null,
    val javaVersion: Int = 21,
    val eulaAccepted: Boolean = false,
    val javaFlags: String = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled",
    val programArguments: String = "",

    // World tab
    val worldType: WorldType = WorldType.NORMAL,
    val worldSeed: String = "",
    val liveWorldMapEnabled: Boolean = false, // squaremap

    // Mods & Plugins tab
    val installedDatapacks: List<InstalledAddon> = emptyList(),
    val installedPlugins: List<InstalledAddon> = emptyList(),

    // Performance tab
    val performanceModeEnabled: Boolean = false,
    val optimizeForPhone: Boolean = true,
    val minRamMb: Int = 1024,
    val maxRamMb: Int = 4096,
    val viewDistanceChunks: Int = 10,
    val simulationDistanceChunks: Int = 10,
    val maxPlayers: Int = 10,

    // Network tab
    val serverPort: Int = 25565,
    val onlineMode: Boolean = false,          // "Block Cracked Players"
    val whitelistEnabled: Boolean = false,
    val bedrockCrossplayEnabled: Boolean = false, // Geyser toggle
    val tunnelMode: TunnelMode = TunnelMode.LOCAL_ONLY,

    val workingDir: String
)

data class InstalledAddon(
    val name: String,
    val fileName: String,
    val modrinthProjectId: String? = null
)

/** Live runtime state — separate from the saved config above. */
data class ServerRuntimeStatus(
    val running: Boolean = false,
    val publicAddress: String? = null,
    val playersOnline: List<String> = emptyList(),
    val ramUsedMb: Int? = null
)
