package com.anvilkt.app.ui.nav

sealed class Dest(val route: String) {
    data object Home : Dest("home")
    data object Plans : Dest("plans")
    data object GuidedSetup : Dest("guided_setup")
    data object Files : Dest("files")
    data object Profile : Dest("profile")
    data object AdminDashboard : Dest("admin_dashboard")

    // Detail screens, parameterized by server id
    data object Console : Dest("console/{serverId}") {
        fun of(serverId: String) = "console/$serverId"
    }
    data object ServerSettings : Dest("server_settings/{serverId}") {
        fun of(serverId: String) = "server_settings/$serverId"
    }
}

/** Icons + labels for the five persistent bottom-bar destinations. */
val bottomBarDestinations = listOf(Dest.Home, Dest.Plans, Dest.GuidedSetup, Dest.Files, Dest.Profile)
