package com.anvilkt.app.ui.server

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.anvilkt.app.auth.SecureCredentialStore
import com.anvilkt.app.data.ServerConfig
import com.anvilkt.app.network.ModrinthRepository
import kotlinx.coroutines.launch

/**
 * Requirement #3's toggle: flipping "Bedrock Support" on calls
 * ModrinthRepository.installBedrockCrossplay, dropping Geyser+Floodgate into
 * plugins/ so the host never has to know those projects exist by name.
 */
@Composable
fun NetworkTab(config: ServerConfig, onChange: (ServerConfig) -> Unit) {
    val repository = remember { ModrinthRepository() }
    val scope = rememberCoroutineScope()
    var installingCrossplay by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val credentialStore = remember { SecureCredentialStore(context) }
    var rconPassword by remember(config.id) { mutableStateOf(credentialStore.getRconPassword(config.id) ?: "") }
    var rconPasswordVisible by remember { mutableStateOf(false) }
    var rconEnabled by remember { mutableStateOf(rconPassword.isNotEmpty()) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            SectionCard(title = "Network") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Server Port", style = MaterialTheme.typography.titleMedium)
                    Text(config.serverPort.toString(), style = MaterialTheme.typography.titleMedium)
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                SettingToggleRow(
                    title = "Block Cracked Players",
                    description = "Verify users with Mojang (online mode)",
                    checked = config.onlineMode,
                    onCheckedChange = { onChange(config.copy(onlineMode = it)) }
                )

                if (!config.onlineMode) {
                    WarningBanner(
                        "Account verification is off. Anyone can log in as any username, so others could impersonate you or your players. Use a whitelist to stay protected."
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                SettingToggleRow(
                    title = "Whitelist",
                    description = "Only allow specific players to join",
                    checked = config.whitelistEnabled,
                    onCheckedChange = { onChange(config.copy(whitelistEnabled = it)) }
                )
            }
        }

        item {
            SectionCard(title = "") {
                SettingToggleRow(
                    title = "Bedrock Support (Geyser)",
                    description = "Let Bedrock Edition players join your server",
                    checked = config.bedrockCrossplayEnabled,
                    onCheckedChange = { enabled ->
                        onChange(config.copy(bedrockCrossplayEnabled = enabled))
                        if (enabled) {
                            installingCrossplay = true
                            scope.launch {
                                runCatching {
                                    repository.installBedrockCrossplay(
                                        mcVersion = config.minecraftVersion,
                                        pluginsDir = java.io.File("${config.workingDir}/plugins")
                                    )
                                }
                                installingCrossplay = false
                            }
                        }
                    }
                )
                if (installingCrossplay) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
                InfoNote("Bedrock players connect on a different IP than Java")
                InfoNote("ViaVersion will be added so older Java clients can connect")
                InfoNote("Geyser requires Java 17 or higher")
            }
        }

        item {
            SectionCard(title = "Remote Console (RCON)") {
                SettingToggleRow(
                    title = "Enable RCON",
                    description = "Lets external tools (a desktop panel, Discord bot) send console commands remotely",
                    checked = rconEnabled,
                    onCheckedChange = { enabled ->
                        rconEnabled = enabled
                        if (!enabled) {
                            credentialStore.clearRconPassword(config.id)
                            rconPassword = ""
                        }
                    }
                )
                if (rconEnabled) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rconPassword,
                        onValueChange = {
                            rconPassword = it
                            // Written straight to the Keystore-encrypted
                            // store — never into ServerConfig/ServerRepository,
                            // which isn't encrypted at rest (see README).
                            credentialStore.setRconPassword(config.id, it)
                        },
                        label = { Text("RCON password") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { rconPasswordVisible = !rconPasswordVisible }) {
                                Icon(
                                    if (rconPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (rconPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        visualTransformation = if (rconPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    InfoNote("Stored encrypted on this device only — never synced or sent anywhere but into server.properties on server start")
                }
            }
        }
    }
}

@Composable
private fun WarningBanner(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
    ) {
        Row(Modifier.padding(12.dp)) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.width(8.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
        }
    }
}

@Composable
private fun InfoNote(text: String) {
    Row(Modifier.padding(top = 6.dp)) {
        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.padding(top = 2.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
